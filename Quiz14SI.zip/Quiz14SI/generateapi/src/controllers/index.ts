export * from './ping.controller';
